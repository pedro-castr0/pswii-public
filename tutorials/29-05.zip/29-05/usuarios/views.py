from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Usuario

def cadastro(request):
    if request.method == 'GET':
        return render(request, 'usuarios/formulario.html')
    elif request.method == 'POST':
        nome = request.POST.get('nome')
        email = request.POST.get('email')
        telefone = request.POST.get('telefone')
        nascimento = request.POST.get('nascimento')
        senha = request.POST.get('senha')

        usuario = Usuario(
            nome = nome,
            email = email,
            telefone = telefone,
            nascimento = nascimento,
            senha = senha
        )

        usuario.save()

        return redirect('listagem')


def listagem(request):
    usuarios = Usuario.objects.all()
    return render(request, 'usuarios/listagem.html', {'usuarios': usuarios})

def atualizar(request, id):
    usuario = Usuario.objects.get(id = id)

    if request.method == 'POST':
        usuario.nome = request.POST.get('nome')
        usuario.email = request.POST.get('email')
        usuario.telefone = request.POST.get('telefone')
        usuario.nascimento = request.POST.get('nascimento')
        usuario.senha = request.POST.get('senha')

        usuario.save()

        return redirect('listagem')
    
    return render(request, 'usuarios/formulario.html', {'usuario':usuario})

def deletar(request, id):
    usuario = Usuario.objects.get(id = id)
    usuario.delete()

    return redirect('listagem')
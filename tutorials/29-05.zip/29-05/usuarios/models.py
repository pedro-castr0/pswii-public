from django.db import models

class Usuario(models.Model):
    nome = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    nascimento = models.DateField()
    telefone = models.IntegerField()
    senha = models.CharField()
